
/*
 * Subject: CMPE 135            Professor Ron Mak
 * Assignment 3: Command Line RPS Game
 * contributors: Aamer Idris, Jacob Balster-Gee, Dan Hoang, Andre Voloshin
 */

#include <iostream>
#include "RPSControl.h"
int main() {

    RPSControl game;
    game.play();

    return 0;
}
